package artigotdd.calculadora.teste;

public class Calculadora {
	 
    public int soma(int valorA, int valorB) {
        return valorA + valorB;
    }
    
    public int subtrai(int valorA, int valorB) {
        return valorA - valorB;
    }
    
    public int divide(int valorA, int valorB) {
        return valorA / valorB;
    }
    
    public int multiplica(int valorA, int valorB) {
        return valorA * valorB;
    }
}
